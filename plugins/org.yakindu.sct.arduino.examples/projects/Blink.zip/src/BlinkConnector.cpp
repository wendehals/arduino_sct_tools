#include "BlinkConnector.h"

BlinkConnector::BlinkConnector(Blink* statemachine) {
	this->statemachine = statemachine;
}

void BlinkConnector::init() {
	// put your code here to initialize your hardware
	pinMode(LED_BUILTIN, OUTPUT);

	// The statemachine has already been initialized and started before.
	// If the cycle period is very high (let's say >> 1s), it takes some
	// time until runCycle() is called the first time. So it might be
	// better to call runCycle() manually, to get in sync with the initial
	// state of the statemachine.
	// runCycle();
}

void BlinkConnector::runCycle() {
	// put your code here to update your hardware depending on the statemachine's state
	digitalWrite(LED_BUILTIN, statemachine->get_on());
}
