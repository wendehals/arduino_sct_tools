
#include "BlinkConnector.h"

BlinkConnector::BlinkConnector(Blink* statemachine) {
	this->statemachine = statemachine;
}

void BlinkConnector::init() {
	// put your code here to initialize your hardware
	 pinMode(LED_BUILTIN, OUTPUT);
}

void BlinkConnector::runCycle() {
	// put your code here to update your hardware depending on the statechart's state
	 digitalWrite(LED_BUILTIN, statemachine->get_on());
}
