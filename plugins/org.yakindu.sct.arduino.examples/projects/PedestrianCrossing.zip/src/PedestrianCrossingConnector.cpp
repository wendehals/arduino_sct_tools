#include "PedestrianCrossingConnector.h"
#include "../src-gen/ArduinoMain.h"

const int button_pin = 2;

const int street_red_pin = 10;
const int street_yellow_pin = 9;
const int street_green_pin = 8;

const int ped_red_pin = 7;
const int ped_wait_pin = 6;
const int ped_green_pin = 5;

// will be called to handle input changes
void button_interrupt() {
	getStatemachine()->getDefaultSCI()->raise_button_pushed();
}

PedestrianCrossingConnector::PedestrianCrossingConnector(PedestrianCrossing* statemachine) {
	this->statemachine = statemachine;
}

void PedestrianCrossingConnector::init() {
	// put your code here to initialize the hardware
	pinMode(street_red_pin, OUTPUT);
	pinMode(street_yellow_pin, OUTPUT);
	pinMode(street_green_pin, OUTPUT);

	pinMode(ped_red_pin, OUTPUT);
	pinMode(ped_wait_pin, OUTPUT);
	pinMode(ped_green_pin, OUTPUT);

	pinMode(button_pin, INPUT);
	attachInterrupt(digitalPinToInterrupt(button_pin), button_interrupt, RISING);
}

void PedestrianCrossingConnector::runCycle() {
	// put your code here to update the hardware depending on the statemachine's state
	digitalWrite(street_red_pin, statemachine->getSCI_Street()->get_red());
	digitalWrite(street_yellow_pin, statemachine->getSCI_Street()->get_yellow());
	digitalWrite(street_green_pin, statemachine->getSCI_Street()->get_green());

	digitalWrite(ped_red_pin, statemachine->getSCI_Ped()->get_red());
	digitalWrite(ped_wait_pin, statemachine->getSCI_Ped()->get_wait());
	digitalWrite(ped_green_pin, statemachine->getSCI_Ped()->get_green());
}

